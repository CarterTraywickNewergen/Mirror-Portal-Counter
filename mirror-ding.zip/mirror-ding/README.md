# Mirror Portal Ding
Build: install the Geode SDK (v5.11.2) + CLI, then in this folder run
  geode build
The resulting .geode file goes in your GD `geode/mods` folder (or run `geode install`).
Before building, change "yourname" in mod.json to your own developer name.
