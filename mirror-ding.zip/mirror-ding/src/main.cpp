#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <algorithm>
#include <vector>

using namespace geode::prelude;

// Object IDs: 45 = mirror portal (on), 46 = mirror portal (off)
static constexpr int MIRROR_ON  = 45;
static constexpr int MIRROR_OFF = 46;

class $modify(MirrorDingPL, PlayLayer) {
	struct Fields {
		std::vector<float> portalXs; // sorted x positions of every mirror portal
		size_t passed = 0;           // how many the player is currently past
		CCLabelBMFont* label = nullptr;
	};

	bool init(GJGameLevel* level, bool useReplay, bool dontCreateObjects) {
		if (!PlayLayer::init(level, useReplay, dontCreateObjects)) return false;

		auto f = m_fields.self();

		// Collect all mirror portals in the level
		for (auto obj : CCArrayExt<GameObject*>(m_objects)) {
			if (!obj) continue;
			int id = obj->m_objectID;
			if (id == MIRROR_ON || id == MIRROR_OFF) {
				f->portalXs.push_back(obj->getPositionX());
			}
		}
		std::sort(f->portalXs.begin(), f->portalXs.end());

		// Counter label
		if (Mod::get()->getSettingValue<bool>("show-counter")) {
			auto winSize = CCDirector::get()->getWinSize();
			f->label = CCLabelBMFont::create("", "bigFont.fnt");
			f->label->setScale(0.45f);
			f->label->setOpacity(160);
			f->label->setAnchorPoint({0.f, 1.f});
			f->label->setPosition({8.f, winSize.height - 8.f});
			f->label->setZOrder(100);
			this->addChild(f->label);
		}
		this->updateLabel();
		return true;
	}

	size_t portalsBehindPlayer() {
		auto f = m_fields.self();
		float x = m_player1->getPositionX();
		return std::upper_bound(f->portalXs.begin(), f->portalXs.end(), x) - f->portalXs.begin();
	}

	void updateLabel() {
		auto f = m_fields.self();
		if (!f->label) return;
		f->label->setString(
			fmt::format("Mirror Portals: {}/{}", f->passed, f->portalXs.size()).c_str()
		);
	}

	void postUpdate(float dt) {
		PlayLayer::postUpdate(dt);

		auto f = m_fields.self();
		if (f->portalXs.empty() || !m_player1) return;

		size_t now = this->portalsBehindPlayer();
		if (now > f->passed) {
			// Ding once for each portal passed this frame
			float vol = static_cast<float>(Mod::get()->getSettingValue<double>("volume"));
			for (size_t i = f->passed; i < now; i++) {
				FMODAudioEngine::sharedEngine()->playEffect("ding.wav"_spr, 1.f, 0.f, vol);
			}
		}
		if (now != f->passed) {
			f->passed = now;
			this->updateLabel();
		}
	}

	void resetLevel() {
		PlayLayer::resetLevel();
		// Re-sync silently (handles dying, practice checkpoints, start pos)
		auto f = m_fields.self();
		if (m_player1) f->passed = this->portalsBehindPlayer();
		this->updateLabel();
	}
};
